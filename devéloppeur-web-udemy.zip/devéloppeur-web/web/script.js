
/*
function table_mutiplication(){
  for ( var i = 0; i <= 10; i++){
    console.log("2 * "+i+" = "+i*2);
    console.log(``)
  }
};
*/

var table_mutiplication = function(){
  for ( var i = 0; i <= 10; i++){
    console.log(`2 x ${i} = ${i * 2}`);
  }
};


table_mutiplication();
