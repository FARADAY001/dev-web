
for (var a = 0; a < 12; a++) {
  console.log("2 x "+a+" = "+a*2 );
}
