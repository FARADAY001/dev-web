var celsium = document.getElementById("celsium");
var fahrenheit = document.getElementById("fahrenheit");
var formule = document.getElementById("formule");
var reponse = document.querySelector("div.reponse");

function celsiumToFahrenheit(){

  if(celsium.value){
    celsium.value = validator(celsium.value) ? parseInt(celsium.value) : 0;
    fahrenheit.value = celsium.value * 9/5 + 32;
    updateTexttarea({celsium: celsium.value, fahrenheit: fahrenheit.value });
    reponse.innerHTML = celsium.value+" c => "+fahrenheit.value+" F";
  }
};

function fahrenheitToCelsium(){
  if(fahrenheit.value){
    fahrenheit.value = validator(fahrenheit.value) ? parseInt(fahrenheit.value) : 0;
    celsium.value = (5/9) * (fahrenheit.value - 32);
    celsium.value = Math.round(celsium.value);
    updateTexttarea({celsium: celsium.value, fahrenheit: fahrenheit.value });
    reponse.innerHTML = fahrenheit.value+" F => "+celsium.value+" c";
  }
};

var updateTexttarea(data) => {
  /* data = {
  celsium : 52,
  fahrenheit: 59
} */
  formule.innerHTML = `${data.celsium}Cx9/5+32= ${data.fahrenheit}F`;
}


var validator = function(data){
  return !isNaN(data);
};
